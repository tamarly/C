var Community ={
"type": "FeatureCollection",
"name": "Community",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "COMMNAME": "Accompong", "Population": 1114.0, "ParName": "St. Elizabeth", "Links": "https:\/\/www.youtube.com\/watch?v=f9gqbKuJpK8", "photo": "accompong.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.74816, 18.22985 ] } },
{ "type": "Feature", "properties": { "COMMNAME": "Elderslie", "Population": 1620.0, "ParName": "St. Elizabeth", "Links": "http:\/\/cockpitcountry.com\/Elderslie.html", "photo": "elderslie.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.79381, 18.22416 ] } },
{ "type": "Feature", "properties": { "COMMNAME": "Quick Step", "Population": 294.0, "ParName": "St. Elizabeth", "Links": "http:\/\/cockpitcountry.com\/Quickstep.html", "photo": "quickstep.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.67831, 18.23281 ] } },
{ "type": "Feature", "properties": { "COMMNAME": "Balaclava", "Population": 4321.0, "ParName": "St. Elizabeth", "Links": "https:\/\/en.wikipedia.org\/wiki\/Balaclava,_Jamaica", "photo": "balaclava.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.6515, 18.17812 ] } },
{ "type": "Feature", "properties": { "COMMNAME": "Maroon Town", "Population": 479.0, "ParName": "St. James", "Links": "http:\/\/cockpitcountry.com\/maroontown.html", "photo": "maroontown.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.79699, 18.35626 ] } },
{ "type": "Feature", "properties": { "COMMNAME": "Duanvale", "Population": 1882.0, "ParName": "Trelawny", "Links": "https:\/\/cockpitcountry.com\/duanvale.html", "photo": "duanvale.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.59615, 18.40267 ] } },
{ "type": "Feature", "properties": { "COMMNAME": "Sawyers", "Population": 607.0, "ParName": "Trelawny", "Links": "http:\/\/cockpitcountry.com\/Sawyers.html", "photo": "sawyers.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.49688, 18.3788 ] } },
{ "type": "Feature", "properties": { "COMMNAME": "Troy", "Population": 2423.0, "ParName": "Trelawny", "Links": "http:\/\/cockpitcountry.com\/troy.html", "photo": "Troy.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.59464, 18.31078 ] } },
{ "type": "Feature", "properties": { "COMMNAME": "Alps", "Population": 478.0, "ParName": "Trelawny", "Links": "https:\/\/www.cockpitcountry.com\/Alps.html", "photo": "alps.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.50897, 18.35498 ] } },
{ "type": "Feature", "properties": { "COMMNAME": "Bunkers Hill", "Population": 1873.0, "ParName": "Trelawny", "Links": "http:\/\/cockpitcountry.com\/bunkershill.html", "photo": "bunkershill.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.68611, 18.36198 ] } }
]
}
