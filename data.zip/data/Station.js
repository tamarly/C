var Station={
"type": "FeatureCollection",
"name": "Station",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "OBJECTID": 119, "NAME": "Warsop", "PARISH": "Trelawny", "E_X_J2001": 688412.1, "N_Y_J2001": 679156.5, "Phone": 8768550913, "photo": "station.jpg" }, "geometry": { "type": "Point", "coordinates": [ -77.5824, 18.26255 ] } }
]
}
