var Oattraction ={
"type": "FeatureCollection",
"name": "Oattraction",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": null, "Name": "Cockpit Country Falls", "Photo": "Falls.jpeg", "Link": null }, "geometry": { "type": "Point", "coordinates": [ -77.5204, 18.29237 ] } },
{ "type": "Feature", "properties": { "id": null, "Name": "Windsor Great House", "Photo": "WindsorGreatHouse.jpg", "Link": "https:\/\/cockpitcountry.com\/WGH%20history.html" }, "geometry": { "type": "Point", "coordinates": [ -77.64697, 18.35643 ] } },
{ "type": "Feature", "properties": { "id": null, "Name": "The Last Resort", "Photo": "Lastresort.jpg", "Link": "http:\/\/www.jamaicancaves.org\/last-resort-jamaica.htm" }, "geometry": { "type": "Point", "coordinates": [ -77.64987, 18.35438 ] } },
{ "type": "Feature", "properties": { "id": null, "Name": "Flagstaff Heritage Centre", "Photo": "FlagstaffGiftShop.jpg", "Link": "https:\/\/www.caribbeanbirdingtrail.org\/sites\/jamaica\/flagstaff\/" }, "geometry": { "type": "Point", "coordinates": [ -77.77921, 18.34129 ] } },
{ "type": "Feature", "properties": { "id": null, "Name": "Black River Head", "Photo": "blackriverhead.jpg", "Link": null }, "geometry": { "type": "Point", "coordinates": [ -77.68141, 18.18844 ] } },
{ "type": "Feature", "properties": { "id": null, "Name": "Noisy River Park", "Photo": "noisyriverfalls17.jpg", "Link": null }, "geometry": { "type": "Point", "coordinates": [ -77.62767, 18.20383 ] } },
{ "type": "Feature", "properties": { "id": null, "Name": "Noisy River Falls", "Photo": "NoisyRiverFalls.jpg", "Link": null }, "geometry": { "type": "Point", "coordinates": [ -77.62794, 18.20491 ] } }
]
}
